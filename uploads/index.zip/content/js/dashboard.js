/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.9868969312613, "KoPercent": 0.013103068738698603};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8810913241025862, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.975929978118162, 500, 1500, "028_GET_api/Organization/GetCurrentOrganizationDetails"], "isController": false}, {"data": [0.9177949709864603, 500, 1500, "058_GET_/api/CooCertificateRequest/print-certifications"], "isController": false}, {"data": [0.9857768052516411, 500, 1500, "027_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.9871212121212121, 500, 1500, "003_GET_/Account/Login"], "isController": false}, {"data": [0.9893617021276596, 500, 1500, "View_Certificates_Page"], "isController": true}, {"data": [0.9901531728665208, 500, 1500, "025_GET_api/BaseOrganizationLookup"], "isController": false}, {"data": [0.9889867841409692, 500, 1500, "043_GET_GetLookups"], "isController": false}, {"data": [0.8761467889908257, 500, 1500, "020_GET_api/RequestInfo/GetDetail"], "isController": false}, {"data": [0.9134980988593155, 500, 1500, "Certificate_Enquiry_Page"], "isController": true}, {"data": [0.39800443458980045, 500, 1500, "Complete_Request"], "isController": true}, {"data": [0.9900881057268722, 500, 1500, "049_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.9559471365638766, 500, 1500, "050_POST_api/Invoice/Save"], "isController": false}, {"data": [0.9801762114537445, 500, 1500, "039_GET_GetLookups"], "isController": false}, {"data": [0.39800443458980045, 500, 1500, "056_POST_api/RequestSummary"], "isController": false}, {"data": [0.9757709251101322, 500, 1500, "052_GET_GetLookups"], "isController": false}, {"data": [0.9217325227963525, 500, 1500, "007_GET_/Account/Login"], "isController": false}, {"data": [0.9384615384615385, 500, 1500, "017_GET_GetCities"], "isController": false}, {"data": [0.9801762114537445, 500, 1500, "037_POST_api/ShippingInfo"], "isController": false}, {"data": [0.9878419452887538, 500, 1500, "008_GET_/connect/authorize-0"], "isController": false}, {"data": [1.0, 500, 1500, "008_GET_/connect/authorize-1"], "isController": false}, {"data": [0.9824945295404814, 500, 1500, "023_GET_GetLookups"], "isController": false}, {"data": [0.9606986899563319, 500, 1500, "021_POST_api/CooCertificateRequest/List"], "isController": false}, {"data": [0.98568281938326, 500, 1500, "048_GET_api/BaseOrganizationLookup"], "isController": false}, {"data": [0.8993362831858407, 500, 1500, "053_GET_api/RequestInfo"], "isController": false}, {"data": [0.9889867841409692, 500, 1500, "042_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.981359649122807, 500, 1500, "031_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.9889867841409692, 500, 1500, "041_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.0, 500, 1500, "Login"], "isController": true}, {"data": [0.32495164410058025, 500, 1500, "Print_Certificate"], "isController": true}, {"data": [0.8660990712074303, 500, 1500, "063_POST_/api/app/attachment/upload"], "isController": false}, {"data": [0.9976599063962559, 500, 1500, "066_GET_GetLookups"], "isController": false}, {"data": [0.9779635258358662, 500, 1500, "008_GET_/connect/authorize"], "isController": false}, {"data": [0.9980988593155894, 500, 1500, "011_GET_certificate-enquiry"], "isController": false}, {"data": [0.9878234398782344, 500, 1500, "009_POST_/connect/token"], "isController": false}, {"data": [0.3730853391684901, 500, 1500, "Start_Cert_Request"], "isController": true}, {"data": [0.9845201238390093, 500, 1500, "064_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.9691629955947136, 500, 1500, "036_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.9866962305986696, 500, 1500, "055_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.981651376146789, 500, 1500, "014_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.989938080495356, 500, 1500, "061_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.8333333333333334, 500, 1500, "033_POST_api/RequestInfo/Save"], "isController": false}, {"data": [0.9686311787072244, 500, 1500, "Certificate_Enquiry"], "isController": true}, {"data": [0.985474006116208, 500, 1500, "016_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.7067833698030634, 500, 1500, "024_GET_api/BaseOrganizationLookup"], "isController": false}, {"data": [0.4911308203991131, 500, 1500, "Submit_Invoices"], "isController": true}, {"data": [0.9992401215805471, 500, 1500, "007_GET_/Account/Login-2"], "isController": false}, {"data": [0.9893617021276596, 500, 1500, "007_GET_/Account/Login-1"], "isController": false}, {"data": [0.39473684210526316, 500, 1500, "065_POST_api/Legalization/New"], "isController": false}, {"data": [0.986322188449848, 500, 1500, "007_GET_/Account/Login-0"], "isController": false}, {"data": [0.7015418502202643, 500, 1500, "Add_Product"], "isController": true}, {"data": [0.8267543859649122, 500, 1500, "030_GET_api/BaseOrganizationLookup"], "isController": false}, {"data": [0.8259187620889749, 500, 1500, "059_GET_/api/CooCertificateRequest/print-certifications"], "isController": false}, {"data": [0.9643962848297214, 500, 1500, "062_GET_/api/Organization/GetRecentOrganizations"], "isController": false}, {"data": [0.9911894273127754, 500, 1500, "046_GET_api/app/attachment/attachments-types"], "isController": false}, {"data": [0.8953744493392071, 500, 1500, "Invoices"], "isController": true}, {"data": [0.9944933920704846, 500, 1500, "047_GET_GetLookups"], "isController": false}, {"data": [0.4923547400611621, 500, 1500, "Home_Page"], "isController": true}, {"data": [0.4076923076923077, 500, 1500, "018_POST_api/Organization/New"], "isController": false}, {"data": [0.706963249516441, 500, 1500, "060_GET_/api/CooCertificateRequest/print-certifications"], "isController": false}, {"data": [0.9537177541729894, 500, 1500, "006_POST_/Account/Login"], "isController": false}, {"data": [0.36923076923076925, 500, 1500, "Create_Org"], "isController": true}, {"data": [0.9846827133479212, 500, 1500, "026_GET_api/BaseOrganizationLookup"], "isController": false}, {"data": [0.9669603524229075, 500, 1500, "038_POST_api/Invoice/get"], "isController": false}, {"data": [0.8824175824175824, 500, 1500, "034_GET_api/ShippingInfo"], "isController": false}, {"data": [0.9893617021276596, 500, 1500, "057_GET_/api/CooCertificateRequest/get-certifications"], "isController": false}, {"data": [0.978021978021978, 500, 1500, "035_GET_GetLookups"], "isController": false}, {"data": [0.9977238239757208, 500, 1500, "005_GET_/Abp/ApplicationConfigurationScript"], "isController": false}, {"data": [0.9341500765696784, 500, 1500, "019_POST_api/CooCertificateRequest/List"], "isController": false}, {"data": [0.9835886214442013, 500, 1500, "022_GET_api/Organization/GetCurrentOrganizationDetails"], "isController": false}, {"data": [0.9889867841409692, 500, 1500, "040_GET_api/Invoice/ProducerByCerReqIdAsync"], "isController": false}, {"data": [0.9417549167927383, 500, 1500, "002_GET_/connect/authorize"], "isController": false}, {"data": [0.8761467889908257, 500, 1500, "View_Certificate"], "isController": true}, {"data": [0.7026431718061674, 500, 1500, "Fill_Shipping_Info"], "isController": true}, {"data": [0.9268060836501901, 500, 1500, "010_POST_api/app/captcha/generate"], "isController": false}, {"data": [0.9701834862385321, 500, 1500, "015_GET_GetLookups"], "isController": false}, {"data": [0.928679817905918, 500, 1500, "004_POST_/Account/Login"], "isController": false}, {"data": [0.986784140969163, 500, 1500, "044_GET_GetLookups"], "isController": false}, {"data": [0.9900221729490022, 500, 1500, "054_GET_api/RequestSummary/get-requester-info"], "isController": false}, {"data": [0.9848714069591528, 500, 1500, "001_GET_"], "isController": false}, {"data": [0.2741228070175439, 500, 1500, "Fill_Cert_Info"], "isController": true}, {"data": [0.9848714069591528, 500, 1500, "Landing_Page"], "isController": true}, {"data": [0.9686311787072244, 500, 1500, "012_POST_api/CooCertificateRequest/CertificateInquiry"], "isController": false}, {"data": [0.9826021180030258, 500, 1500, "002_GET_/connect/authorize-0"], "isController": false}, {"data": [0.8458149779735683, 500, 1500, "051_GET_api/RequestSummary"], "isController": false}, {"data": [0.989409984871407, 500, 1500, "002_GET_/connect/authorize-1"], "isController": false}, {"data": [0.6259541984732825, 500, 1500, "013_POST_api/Organization/get-applicant-organizations"], "isController": false}, {"data": [0.9781181619256017, 500, 1500, "029_GET_GetLookups"], "isController": false}, {"data": [0.9944933920704846, 500, 1500, "045_GET_api/BaseOrganizationLookup"], "isController": false}, {"data": [0.8651315789473685, 500, 1500, "032_GET_api/RequestInfo/GetProducerAttachments"], "isController": false}, {"data": [0.9341500765696784, 500, 1500, "Certifications_Requests_Page"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 38159, 5, 0.013103068738698603, 246.600618464843, 4, 8599, 89.0, 552.0, 974.0, 2180.9900000000016, 63.5409346889976, 2952.125172383343, 144.4753824982266], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["028_GET_api/Organization/GetCurrentOrganizationDetails", 457, 0, 0.0, 130.6236323851202, 57, 6428, 74.0, 111.19999999999999, 184.1999999999996, 1745.0000000000016, 0.7661447829228507, 1.7956518349754313, 1.490391023029608], "isController": false}, {"data": ["058_GET_/api/CooCertificateRequest/print-certifications", 517, 0, 0.0, 341.5957446808513, 139, 4113, 228.0, 632.0, 778.9999999999993, 2413.8200000000725, 0.8684521729782031, 159.18154609736155, 1.7377524437815801], "isController": false}, {"data": ["027_GET_api/app/attachment/attachments-types", 457, 0, 0.0, 88.14004376367615, 45, 2288, 55.0, 79.0, 144.69999999999976, 1059.220000000004, 0.7661730411034233, 0.6576817413378019, 1.4283440776039404], "isController": false}, {"data": ["003_GET_/Account/Login", 660, 0, 0.0, 199.62575757575766, 133, 1756, 173.0, 245.0, 309.74999999999966, 854.3599999999997, 1.1003282645989387, 17.805671725919066, 1.4420317686443123], "isController": false}, {"data": ["View_Certificates_Page", 517, 0, 0.0, 103.35009671179887, 52, 2666, 67.0, 134.39999999999998, 193.09999999999997, 1023.6200000000046, 0.8686404013555494, 1.982434197234296, 1.7491567456983819], "isController": true}, {"data": ["025_GET_api/BaseOrganizationLookup", 457, 0, 0.0, 83.54923413566736, 45, 2430, 58.0, 90.19999999999999, 123.79999999999973, 840.7200000000018, 0.7661473517622228, 3.1573650629263477, 1.4193178967704458], "isController": false}, {"data": ["043_GET_GetLookups", 454, 0, 0.0, 89.52422907488985, 41, 2752, 63.0, 107.5, 166.5, 834.6999999999997, 0.7640267914240517, 1.1743927438490793, 1.4676178698545992], "isController": false}, {"data": ["020_GET_api/RequestInfo/GetDetail", 327, 0, 0.0, 345.19877675840985, 59, 3114, 126.0, 916.8, 1405.1999999999994, 2265.159999999997, 0.5478295395718888, 1.0776101271400116, 1.072119528615298], "isController": false}, {"data": ["Certificate_Enquiry_Page", 526, 0, 0.0, 315.494296577947, 113, 3822, 156.0, 624.9000000000001, 1012.249999999999, 2739.450000000014, 0.879604545849805, 19.240516580587496, 2.077034952992997], "isController": true}, {"data": ["Complete_Request", 451, 0, 0.0, 1404.365853658535, 872, 8599, 1278.0, 1833.6, 2330.599999999999, 5272.72000000001, 0.7637504720519824, 0.6205472585422358, 1.739322364087132], "isController": true}, {"data": ["049_GET_api/app/attachment/attachments-types", 454, 0, 0.0, 82.79515418502201, 45, 1809, 56.0, 97.5, 183.5, 764.549999999997, 0.7657432769764273, 0.6550694439759279, 1.4926011531688952], "isController": false}, {"data": ["050_POST_api/Invoice/Save", 454, 0, 0.0, 215.37004405286348, 88, 4769, 111.0, 237.5, 745.5, 2866.7999999999975, 0.7656967840735069, 0.3447131029862175, 2.421964730091884], "isController": false}, {"data": ["039_GET_GetLookups", 454, 0, 0.0, 121.8480176211454, 41, 6729, 64.0, 122.5, 226.25, 1758.4999999999964, 0.7640255056620348, 1.2106711980895997, 1.4676154000363502], "isController": false}, {"data": ["056_POST_api/RequestSummary", 451, 0, 0.0, 1404.365853658535, 872, 8599, 1278.0, 1833.6, 2330.599999999999, 5272.72000000001, 0.7637504720519824, 0.6205472585422358, 1.739322364087132], "isController": false}, {"data": ["052_GET_GetLookups", 454, 0, 0.0, 123.11894273127751, 41, 3587, 66.0, 173.0, 362.75, 1711.3499999999967, 0.765889249715322, 1.0717961863691958, 1.4704475243557842], "isController": false}, {"data": ["007_GET_/Account/Login", 658, 0, 0.0, 407.0258358662614, 239, 3800, 331.5, 592.6000000000001, 755.049999999999, 1591.8599999999922, 1.098818519600885, 5.018685681334279, 7.740017560430843], "isController": false}, {"data": ["017_GET_GetCities", 65, 0, 0.0, 205.43076923076927, 45, 2908, 60.0, 597.5999999999995, 1101.1, 2908.0, 0.11004881088027198, 0.8159550564889011, 0.21139258886864742], "isController": false}, {"data": ["037_POST_api/ShippingInfo", 454, 0, 0.0, 171.4361233480178, 78, 7364, 102.0, 173.5, 273.25, 2373.599999999995, 0.7639946486718442, 0.34469289813124215, 1.7540541201440483], "isController": false}, {"data": ["008_GET_/connect/authorize-0", 658, 0, 0.0, 232.46048632218825, 150, 1754, 204.0, 301.1, 351.2999999999997, 997.709999999999, 1.0991452391810197, 1.0146953646096948, 3.118774372668701], "isController": false}, {"data": ["008_GET_/connect/authorize-1", 658, 0, 0.0, 28.630699088145896, 5, 424, 7.0, 88.10000000000002, 151.04999999999995, 298.81999999999994, 1.0993435682553685, 3.212144488496155, 1.3935038589799496], "isController": false}, {"data": ["023_GET_GetLookups", 457, 0, 0.0, 104.70021881838086, 41, 4761, 61.0, 102.39999999999998, 195.99999999999932, 1307.060000000011, 0.7662385567217732, 1.108461148917709, 1.4075143800719292], "isController": false}, {"data": ["021_POST_api/CooCertificateRequest/List", 458, 0, 0.0, 211.61353711790375, 66, 5554, 120.0, 289.60000000000014, 701.8999999999992, 2100.919999999987, 0.7667363648995459, 4.438128884951041, 1.5641721350343274], "isController": false}, {"data": ["048_GET_api/BaseOrganizationLookup", 454, 0, 0.0, 95.45374449339202, 48, 2409, 61.0, 103.0, 238.75, 843.8999999999995, 0.7657226127669909, 2.828848096087225, 1.4828397862470146], "isController": false}, {"data": ["053_GET_api/RequestInfo", 452, 0, 0.0, 291.59070796460156, 57, 3347, 78.0, 666.8, 1316.6499999999987, 2567.6799999999985, 0.7625062839289991, 1.0826993523757469, 1.466931034511844], "isController": false}, {"data": ["042_GET_api/app/attachment/attachments-types", 454, 0, 0.0, 89.57488986784142, 45, 2976, 57.0, 94.0, 193.0, 964.5999999999983, 0.7640255056620348, 0.6483771136917073, 1.4885067224567963], "isController": false}, {"data": ["031_GET_api/app/attachment/attachments-types", 456, 0, 0.0, 110.42543859649125, 45, 7012, 54.0, 71.30000000000001, 104.14999999999998, 2069.640000000002, 0.7661058637339597, 0.6576240763888189, 1.4925597638176267], "isController": false}, {"data": ["041_GET_api/app/attachment/attachments-types", 454, 0, 0.0, 89.10132158590307, 46, 3952, 57.0, 99.5, 174.0, 788.6499999999992, 0.7640345060870326, 0.696883035825477, 1.4885242574644824], "isController": false}, {"data": ["Login", 657, 0, 0.0, 2269.404870624049, 1628, 6423, 2092.0, 3000.2000000000007, 3478.7000000000007, 4808.419999999979, 1.0955203721767839, 79.89938287092619, 24.954675736599885], "isController": true}, {"data": ["Print_Certificate", 517, 0, 0.0, 1533.473887814314, 705, 9469, 1280.0, 2297.3999999999996, 3492.4999999999995, 6379.700000000004, 0.8671295830398175, 1109.443705959524, 5.289998540282949], "isController": true}, {"data": ["063_POST_/api/app/attachment/upload", 646, 0, 0.0, 535.6981424148605, 227, 8182, 329.5, 1002.3000000000014, 1421.7999999999988, 4171.429999999999, 1.0850249757297046, 0.46728126396171843, 16.69051924785598], "isController": false}, {"data": ["066_GET_GetLookups", 641, 0, 0.0, 59.50546021840874, 7, 552, 30.0, 156.0, 240.79999999999995, 429.2800000000027, 1.0803267609241933, 21.099077042698188, 2.11317822473746], "isController": false}, {"data": ["008_GET_/connect/authorize", 658, 0, 0.0, 261.2841945288756, 156, 1759, 222.0, 363.1, 477.3499999999997, 1005.119999999999, 1.0990332516017824, 4.225829763319515, 4.51156712140977], "isController": false}, {"data": ["011_GET_certificate-enquiry", 526, 0, 0.0, 40.055133079847934, 6, 528, 19.0, 91.20000000000005, 160.64999999999998, 312.73, 0.8797649054085471, 17.182049163345248, 0.2156454992749466], "isController": false}, {"data": ["009_POST_/connect/token", 657, 0, 0.0, 174.11111111111143, 109, 1733, 148.0, 212.4000000000001, 275.1, 841.6599999999991, 1.0985428005317148, 7.6211406786887705, 2.4309158755737252], "isController": false}, {"data": ["Start_Cert_Request", 457, 0, 0.0, 1309.90590809628, 512, 10429, 1055.0, 2181.7999999999997, 2936.7999999999965, 4737.400000000021, 0.7652967241281144, 646.6481678747233, 8.644714070302635], "isController": true}, {"data": ["064_GET_api/app/attachment/attachments-types", 646, 0, 0.0, 94.22291021671835, 44, 4018, 56.0, 90.9000000000002, 213.89999999999986, 1025.6199999999985, 1.0859862385706673, 0.9406931578243963, 2.116824738463918], "isController": false}, {"data": ["036_GET_api/app/attachment/attachments-types", 454, 0, 0.0, 136.94493392070478, 45, 4275, 58.0, 172.0, 423.75, 2384.7999999999984, 0.7641000870131597, 0.6529175548208151, 1.4886520249914585], "isController": false}, {"data": ["055_GET_api/app/attachment/attachments-types", 451, 0, 0.0, 93.92461197339252, 45, 1704, 57.0, 132.60000000000002, 259.3999999999995, 923.9200000000019, 0.7651317095349662, 0.6552934660763333, 1.490661875510017], "isController": false}, {"data": ["014_GET_api/app/attachment/attachments-types", 654, 0, 0.0, 99.70489296636082, 43, 3253, 56.0, 97.0, 188.75, 1055.2000000000044, 1.0946907498631637, 0.8990575396825398, 2.039716748768473], "isController": false}, {"data": ["061_GET_api/app/attachment/attachments-types", 646, 0, 0.0, 81.36532507739939, 44, 2387, 56.0, 84.0, 158.5999999999999, 862.5699999999954, 1.0854643552660983, 0.9402410967978803, 2.1158074737413406], "isController": false}, {"data": ["033_POST_api/RequestInfo/Save", 456, 0, 0.0, 637.2324561403506, 237, 7468, 321.0, 1238.8000000000002, 2303.0999999999995, 5092.810000000004, 0.7650993874171352, 0.3451913251823403, 2.4955390175519843], "isController": false}, {"data": ["Certificate_Enquiry", 526, 1, 0.19011406844106463, 195.39163498098878, 83, 3800, 127.0, 251.20000000000005, 456.65, 1981.6300000000024, 0.8796016040187425, 0.7945358669677824, 0.40286440652811545], "isController": true}, {"data": ["016_GET_api/app/attachment/attachments-types", 654, 0, 0.0, 92.53058103975545, 44, 3550, 56.0, 92.0, 175.25, 870.4500000000037, 1.0946596010350726, 0.8990319574907187, 2.131593012171811], "isController": false}, {"data": ["024_GET_api/BaseOrganizationLookup", 457, 0, 0.0, 699.2844638949674, 193, 4959, 536.0, 1286.4, 1533.7999999999997, 2745.420000000017, 0.7657262922259512, 635.162848132139, 1.418537867531865], "isController": false}, {"data": ["Submit_Invoices", 451, 0, 0.0, 1260.90243902439, 376, 5974, 846.0, 2866.8, 3568.199999999997, 5182.520000000002, 0.7639419404125286, 3.9980125572956453, 9.826054001145913], "isController": true}, {"data": ["007_GET_/Account/Login-2", 658, 0, 0.0, 36.54559270516722, 4, 537, 7.0, 115.10000000000002, 202.24999999999977, 348.6399999999999, 1.0994648045943594, 3.212498725924144, 1.3936575355112095], "isController": false}, {"data": ["007_GET_/Account/Login-1", 658, 0, 0.0, 232.56382978723417, 149, 1919, 203.0, 298.0, 353.0, 1091.059999999998, 1.0990883246085543, 0.9981563023027403, 3.116945795569572], "isController": false}, {"data": ["065_POST_api/Legalization/New", 646, 4, 0.6191950464396285, 1213.575851393188, 50, 6067, 882.0, 2402.9000000000015, 3084.65, 4508.799999999998, 1.0850304429981106, 0.8825287371404577, 2.759434705017846], "isController": false}, {"data": ["007_GET_/Account/Login-0", 658, 0, 0.0, 137.55015197568406, 79, 2446, 103.0, 189.20000000000005, 278.0, 998.5999999999981, 1.0991323869881433, 0.8103954611094222, 3.2319215011926756], "isController": false}, {"data": ["Add_Product", 454, 0, 0.0, 709.2555066079299, 397, 8081, 509.0, 1121.0, 1657.25, 3617.849999999997, 0.7635012755852809, 12.465821650979013, 11.820848850711956], "isController": true}, {"data": ["030_GET_api/BaseOrganizationLookup", 456, 0, 0.0, 516.5307017543857, 203, 3599, 388.0, 828.9000000000001, 1266.4499999999994, 2781.1000000000004, 0.765626075612291, 638.8971239544, 1.4826528397843486], "isController": false}, {"data": ["059_GET_/api/CooCertificateRequest/print-certifications", 517, 0, 0.0, 510.6402321083175, 203, 6158, 361.0, 814.7999999999997, 1213.2999999999993, 3495.600000000019, 0.8682465282734322, 317.79977117998817, 1.758538378553807], "isController": false}, {"data": ["062_GET_/api/Organization/GetRecentOrganizations", 646, 0, 0.0, 141.50154798761614, 50, 3700, 63.0, 206.30000000000211, 535.65, 1665.3699999999965, 1.0854461166736957, 2.103051851055285, 2.1041118570285997], "isController": false}, {"data": ["046_GET_api/app/attachment/attachments-types", 454, 0, 0.0, 80.19823788546258, 45, 1661, 55.5, 96.0, 176.75, 753.1999999999994, 0.7657226127669909, 0.6550517663905118, 1.492560874104408], "isController": false}, {"data": ["Invoices", 454, 0, 0.0, 456.0066079295156, 198, 7994, 251.5, 883.5, 1456.5, 4103.049999999999, 0.763813414178665, 2.726773274227522, 5.997874671299459], "isController": true}, {"data": ["047_GET_GetLookups", 454, 0, 0.0, 80.08370044052863, 41, 1033, 61.0, 106.0, 147.0, 805.6999999999995, 0.7657058239180189, 1.853696032707782, 1.4708431207487724], "isController": false}, {"data": ["Home_Page", 654, 0, 0.0, 1174.1269113149858, 299, 7006, 928.0, 2293.5, 3100.5, 4363.450000000008, 1.0938466942079645, 361.23161046032715, 8.429209778345514], "isController": true}, {"data": ["018_POST_api/Organization/New", 65, 0, 0.0, 1158.1846153846154, 617, 4485, 877.0, 2077.7999999999993, 3264.6999999999985, 4485.0, 0.10994382716153793, 0.06044763153510337, 0.36074162027178114], "isController": false}, {"data": ["060_GET_/api/CooCertificateRequest/print-certifications", 517, 0, 0.0, 681.2379110251447, 327, 8369, 525.0, 972.2, 1364.1999999999994, 3355.940000000006, 0.8682538189732772, 633.934473956479, 1.8009483510734776], "isController": false}, {"data": ["006_POST_/Account/Login", 659, 0, 0.0, 406.6843702579666, 291, 3085, 348.0, 457.0, 885.0, 1358.3999999999992, 1.099733660861497, 2.2123548255612144, 2.8492123068999526], "isController": false}, {"data": ["Create_Org", 65, 0, 0.0, 1363.6307692307691, 678, 4757, 979.0, 2801.3999999999996, 4074.9999999999964, 4757.0, 0.10993397196514586, 0.875545798387015, 0.5718812789210911], "isController": true}, {"data": ["026_GET_api/BaseOrganizationLookup", 457, 0, 0.0, 98.1378555798688, 44, 5966, 55.0, 78.0, 145.5999999999991, 1209.760000000003, 0.7661627651602152, 1.358741778838819, 1.4193464506923126], "isController": false}, {"data": ["038_POST_api/Invoice/get", 454, 0, 0.0, 153.7775330396477, 51, 4349, 66.0, 178.5, 496.0, 2643.8999999999983, 0.764037077675981, 0.3424736510285891, 1.5541887039053401], "isController": false}, {"data": ["034_GET_api/ShippingInfo", 455, 0, 0.0, 367.22197802197786, 60, 4622, 119.0, 978.600000000001, 1519.0, 3052.6, 0.764134386887118, 0.5813092650244774, 1.5014046742352356], "isController": false}, {"data": ["057_GET_/api/CooCertificateRequest/get-certifications", 517, 0, 0.0, 103.34816247582212, 52, 2666, 67.0, 134.39999999999998, 193.09999999999997, 1023.6200000000046, 0.8686404013555494, 1.982434197234296, 1.7491567456983819], "isController": false}, {"data": ["035_GET_GetLookups", 455, 0, 0.0, 104.6769230769231, 41, 2592, 63.0, 123.60000000000014, 209.59999999999974, 1331.519999999999, 0.7641613371311872, 1.2768359842104116, 1.4671300671874161], "isController": false}, {"data": ["005_GET_/Abp/ApplicationConfigurationScript", 659, 0, 0.0, 53.82549317147198, 26, 605, 35.0, 86.0, 147.0, 399.9999999999993, 1.100321247053009, 5.89703418342472, 1.3453146497171555], "isController": false}, {"data": ["019_POST_api/CooCertificateRequest/List", 653, 0, 0.0, 267.5895865237361, 64, 4976, 124.0, 520.8000000000006, 989.9999999999968, 2592.9400000000032, 1.093707080790283, 6.3303642574264885, 2.2312051677450206], "isController": false}, {"data": ["022_GET_api/Organization/GetCurrentOrganizationDetails", 457, 0, 0.0, 112.38512035010933, 59, 1858, 75.0, 136.59999999999997, 218.2999999999999, 1051.0400000000002, 0.7662398414537431, 1.7958746284072105, 1.4262237673933928], "isController": false}, {"data": ["040_GET_api/Invoice/ProducerByCerReqIdAsync", 454, 0, 0.0, 91.2797356828194, 45, 4261, 56.0, 103.5, 167.5, 900.3499999999988, 0.7640242199043454, 0.47751513744021595, 1.4892503348916735], "isController": false}, {"data": ["002_GET_/connect/authorize", 661, 0, 0.0, 306.8714069591526, 175, 2139, 227.0, 554.0000000000003, 726.6999999999999, 1146.2399999999996, 1.1013307607846272, 19.270099182249414, 2.230624997917302], "isController": false}, {"data": ["View_Certificate", 327, 0, 0.0, 345.19877675840985, 59, 3114, 126.0, 916.8, 1405.1999999999994, 2265.159999999997, 0.5478295395718888, 1.0776101271400116, 1.072119528615298], "isController": true}, {"data": ["Fill_Shipping_Info", 454, 0, 0.0, 779.5044052863436, 240, 7783, 464.5, 1788.0, 2456.75, 4138.549999999992, 0.763759446055704, 2.854401757866386, 6.20852893453875], "isController": true}, {"data": ["010_POST_api/app/captcha/generate", 526, 0, 0.0, 275.4391634980991, 102, 3815, 124.0, 553.9000000000001, 896.7499999999997, 2721.1100000000147, 0.8796280812067293, 2.0616544449647143, 1.8614785663818187], "isController": false}, {"data": ["015_GET_GetLookups", 654, 0, 0.0, 123.69266055045874, 40, 2863, 65.0, 123.0, 448.25, 1798.8000000000084, 1.0946614332700082, 2.704583423997188, 2.101664431453941], "isController": false}, {"data": ["004_POST_/Account/Login", 659, 0, 0.0, 458.53262518968126, 320, 2971, 387.0, 532.0, 1038.0, 2024.3999999999996, 1.0998676487032746, 18.182641803545113, 2.4940358205947297], "isController": false}, {"data": ["044_GET_GetLookups", 454, 0, 0.0, 105.9405286343613, 42, 6193, 65.0, 117.5, 183.25, 1444.4999999999977, 0.7646637753168555, 1.8511733388774263, 1.4688414512189987], "isController": false}, {"data": ["054_GET_api/RequestSummary/get-requester-info", 451, 0, 0.0, 94.92461197339242, 46, 2555, 59.0, 139.20000000000005, 208.39999999999986, 742.5200000000013, 0.7651330076004342, 0.44757292143814464, 1.501872407496946], "isController": false}, {"data": ["001_GET_", 661, 0, 0.0, 91.85022692889558, 28, 787, 45.0, 206.00000000000034, 402.69999999999993, 659.2999999999998, 1.1015895553977888, 21.654195469337978, 0.6196441249112562], "isController": false}, {"data": ["Fill_Cert_Info", 456, 0, 0.0, 1958.9385964912274, 802, 12934, 1413.0, 3975.8, 4834.15, 7603.200000000008, 0.7641224405668582, 642.5941882235912, 11.347665970410363], "isController": true}, {"data": ["Landing_Page", 661, 0, 0.0, 91.85022692889558, 28, 787, 45.0, 206.00000000000034, 402.69999999999993, 659.2999999999998, 1.1015895553977888, 21.654195469337978, 0.6196441249112562], "isController": true}, {"data": ["012_POST_api/CooCertificateRequest/CertificateInquiry", 526, 1, 0.19011406844106463, 195.38973384030413, 83, 3800, 127.0, 251.20000000000005, 456.65, 1981.6300000000024, 0.8796030749318141, 0.794537195629744, 0.40286508021779377], "isController": false}, {"data": ["002_GET_/connect/authorize-0", 661, 0, 0.0, 102.56429652042362, 37, 1725, 45.0, 263.4000000000002, 429.29999999999984, 716.9799999999999, 1.101582212030411, 1.183340266829543, 0.9950815880157521], "isController": false}, {"data": ["051_GET_api/RequestSummary", 454, 0, 0.0, 441.0330396475771, 61, 4700, 151.5, 1164.0, 1936.25, 3683.8999999999896, 0.765530230856264, 0.3999596420977552, 1.4884479390965057], "isController": false}, {"data": ["002_GET_/connect/authorize-1", 661, 0, 0.0, 204.08925869894085, 135, 2097, 175.0, 275.0, 344.5999999999999, 609.6399999999999, 1.1014133415980991, 18.088385244310473, 1.2358632123986482], "isController": false}, {"data": ["013_POST_api/Organization/get-applicant-organizations", 655, 0, 0.0, 857.7129770992367, 148, 5813, 623.0, 1819.3999999999996, 2276.399999999998, 3787.9199999999737, 1.094783149365193, 357.06540941494706, 2.162838194497837], "isController": false}, {"data": ["029_GET_GetLookups", 457, 0, 0.0, 109.1509846827133, 41, 4475, 65.0, 93.59999999999997, 148.99999999999966, 1834.9200000000012, 0.7661332233588488, 1.114156666176308, 1.4716641116668512], "isController": false}, {"data": ["045_GET_api/BaseOrganizationLookup", 454, 0, 0.0, 85.68502202643172, 49, 2942, 61.0, 101.0, 158.5, 454.4999999999992, 0.7657355277671895, 2.828895808631054, 1.4828647964475943], "isController": false}, {"data": ["032_GET_api/RequestInfo/GetProducerAttachments", 456, 0, 0.0, 366.58991228070187, 52, 3625, 84.5, 999.0000000000001, 1479.5999999999985, 3115.2100000000005, 0.7653626409039336, 0.393892687262083, 1.5105448215496577], "isController": false}, {"data": ["Certifications_Requests_Page", 653, 0, 0.0, 267.5895865237361, 64, 4976, 124.0, 520.8000000000006, 989.9999999999968, 2592.9400000000032, 1.0937089126389539, 6.33037486014595, 2.2312089047878656], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 4, 80.0, 0.010482454990958883], "isController": false}, {"data": ["503/Service Unavailable", 1, 20.0, 0.0026206137477397208], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 38159, 5, "400/Bad Request", 4, "503/Service Unavailable", 1, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["065_POST_api/Legalization/New", 646, 4, "400/Bad Request", 4, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["012_POST_api/CooCertificateRequest/CertificateInquiry", 526, 1, "503/Service Unavailable", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
